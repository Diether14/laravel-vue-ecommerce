jQuery(() => {
    $('.select2').select2({
        theme: 'bootstrap4'
    })
})